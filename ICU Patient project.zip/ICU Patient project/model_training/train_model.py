import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

# ✅ Load dataset safely
csv_file = "model_training/patient_data.csv"

try:
    df = pd.read_csv(csv_file)  # Make sure file exists
except FileNotFoundError:
    print("❌ ERROR: patient_data.csv not found! Please generate it first.")
    exit()

# ✅ Ensure required columns exist
required_columns = [
    "Age", "BMI", "Respiratory_Rate", "Diastolic_BP", "Systolic_BP",
    "Temperature", "SpO2", "Heart_Rate", "Glucose_Level", "pH", "medical_history"  # Ensure all 11
]


missing_columns = [col for col in required_columns if col not in df.columns]
if missing_columns:
    print(f"❌ ERROR: Missing columns in dataset: {missing_columns}")
    exit()

# ✅ Encode 'Risk_Level' as numerical labels
df["Risk_Level"] = df["Risk_Level"].map({"Stable": 0, "Moderate": 1, "Critical": 2})

# ✅ Select features and labels (ENSURE THESE MATCH DURING TRAINING & PREDICTION)
X = df.drop(columns=["Patient_ID", "Risk_Level"], errors="ignore")  # Features (ignore Patient_ID)
y = df["Risk_Level"]  # Labels

# ✅ Normalize numerical features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ✅ Split dataset (80% Train, 20% Test)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)

# ✅ Train the RandomForest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# ✅ Save the trained model & scaler
model_path = "model_training/patient_risk.pkl"
scaler_path = "model_training/scaler.pkl"

with open(model_path, "wb") as file:
    pickle.dump(model, file)

with open(scaler_path, "wb") as file:
    pickle.dump(scaler, file)

print(f"✅ Model trained and saved successfully!")
