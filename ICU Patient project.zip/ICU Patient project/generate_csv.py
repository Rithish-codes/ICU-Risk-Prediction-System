import pandas as pd
import numpy as np
import random

# ✅ Define column names
columns = [
    "Patient_ID", "Age", "BMI", "Respiratory_Rate", "Diastolic_BP",
    "Systolic_BP", "Temperature", "SpO2", "Heart_Rate",
    "Glucose_Level", "medical_history", "Risk_Level"
]

# ✅ Number of samples
num_samples = 1000

# ✅ Generate synthetic ICU patient data
data = {
    "Patient_ID": [f"P{1000+i}" for i in range(num_samples)],
    "Age": np.random.randint(20, 90, size=num_samples),
    "BMI": np.round(np.random.uniform(18.5, 40.0, size=num_samples), 1),
    "Respiratory_Rate": np.random.randint(10, 40, size=num_samples),  # Breaths per min
    "Diastolic_BP": np.random.randint(60, 120, size=num_samples),
    "Systolic_BP": np.random.randint(90, 180, size=num_samples),
    "Temperature": np.round(np.random.uniform(35.0, 40.5, size=num_samples), 1),  # Celsius
    "SpO2": np.random.randint(80, 100, size=num_samples),  # Oxygen Saturation
    "Heart_Rate": np.random.randint(50, 140, size=num_samples),  # BPM
    "Glucose_Level": np.random.randint(70, 250, size=num_samples),  # mg/dL
    "pH": [round(random.uniform(7.0, 7.8), 2) for _ in range(num_samples)],  # Blood pH
    "medical_history": np.random.choice([0, 1], size=num_samples),  # 1 = High Risk, 0 = Normal
}

# ✅ Create DataFrame
df = pd.DataFrame(data)

# ✅ Generate risk levels based on ICU admission & vitals
def assign_risk(row):
    if row["medical_history"] == 1 or row["SpO2"] < 90 or row["Heart_Rate"] > 120 or row["Systolic_BP"] > 160:
        return "Critical"
    elif row["Heart_Rate"] > 100 or row["SpO2"] < 95 or row["Systolic_BP"] > 140:
        return "Moderate"
    else:
        return "Stable"

df["Risk_Level"] = df.apply(assign_risk, axis=1)

# ✅ Save dataset
csv_filename = "model_training/patient_data.csv"
df.to_csv(csv_filename, index=False)

# ✅ Print message without Unicode
print(f"Dataset '{csv_filename}' created successfully with {num_samples} records!")
