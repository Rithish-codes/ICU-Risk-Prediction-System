from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash
from models import db, User  # Import models

# ✅ Initialize Flask App
app = Flask(__name__)

# ✅ Configure App
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///patients.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# ✅ Initialize Extensions
bcrypt = Bcrypt(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

migrate = Migrate(app, db)
db.init_app(app)

# ✅ Load User for LoginManager
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))  # Corrected for SQLAlchemy 2.0


    # Register Route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        # ✅ Check if all fields are filled
        if not username or not email or not password:
            flash("All fields are required!", "danger")
            return redirect(url_for('register'))

        # ✅ Check if passwords match
        if password != confirm_password:
            flash("Passwords do not match!", "danger")
            return redirect(url_for('register'))

        # ✅ Check if the username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash("Username is already taken!", "warning")
            return redirect(url_for('register'))

        # ✅ Check if the email is already registered
        existing_email = User.query.filter_by(email=email).first()
        if existing_email:
            flash("Email is already registered!", "warning")
            return redirect(url_for('register'))

        # ✅ Hash the password before storing
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')

        # ✅ Create a new user object
        new_user = User(username=username, email=email, password=hashed_password)
        db.session.add(new_user)

        try:
            db.session.commit()
            flash("Registration successful! Please login.", "success")
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f"Error registering user: {str(e)}", "danger")

    return render_template('register.html')


# Login Route
@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            flash("Login successful!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid email or password", "danger")

    return render_template('login.html')


# Logout Route
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))