import os
from flask import Blueprint,  request, jsonify, render_template, redirect, url_for, flash, current_app
import pickle
import numpy as np
from models import  Patient, db
import pandas as pd  
from sklearn.preprocessing import StandardScaler  
from datetime import datetime
import threading, time, random
from app import app
import numpy as np


# Create API blueprint
api_routes = Blueprint('api_routes', __name__)

feature_columns = ["Name", "Age", "BMI", "Respiratory_Rate", "Diastolic_BP", "Systolic_BP",
                   "Temperature", "SpO2", "Heart_Rate", "Glucose_Level", "pH", "medical_history"]

# ✅ Load Model & Scaler
model_path = os.path.join("model_training", "patient_risk.pkl")
scaler_path = os.path.join("model_training", "scaler.pkl")

if os.path.exists(model_path) and os.path.exists(scaler_path):
    with open(model_path, "rb") as file:
        model = pickle.load(file)
    with open(scaler_path, "rb") as file:
        scaler = pickle.load(file)
    print("✅ Model and scaler loaded successfully!")
else:
    model, scaler = None, None
    print("❌ Model or scaler file not found! Train the model first.")


# ✅ Render Dashboard Page
@api_routes.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


# ✅ ICU Risk Prediction
api_routes.route("/api/predict_risk", methods=["GET"])
def predict_risk():
    if model is None or scaler is None:
        return jsonify({"error": "Model or scaler not loaded"}), 500

    # Fetch all patients
    patients = Patient.query.all()
    if not patients:
        return jsonify({"error": "No patient data available"}), 404

    predictions = []

    for patient in patients:
        try:
            features = np.array([[patient.age, patient.bmi, patient.respiratory_rate,
                                  patient.diastolic_bp, patient.systolic_bp, patient.temperature,
                                  patient.spo2, patient.heart_rate, patient.glucose, patient.ph, patient.medical_history]])
            

            # Convert to DataFrame with correct column names
            # # Scale features
            features_scaled = scaler.transform(features)

            # Predict risk level
            risk_prediction = model.predict(features_scaled)[0]

            # Convert numeric prediction to labels
            risk_levels = {0: "Stable", 1: "Moderate", 2: "Critical"}
            risk_level = risk_levels.get(risk_prediction, "Unknown")

            predictions.append({
                "patient_id": patient.id,
                "name": patient.name
            })
        except Exception as e:
            print(f"Error processing patient {patient.id}: {str(e)}")

    return jsonify({"predictions": predictions})


@api_routes.route("/api/predict_risk/<int:patient_id>", methods=["GET"])
def predict_risk_for_patient(patient_id):
    if model is None or scaler is None:
        return jsonify({"error": "Model or scaler not loaded"}), 500

    # Get patient from database
    patient = Patient.query.get(patient_id)
    if not patient:
        return jsonify({"error": f"No patient found with ID {patient_id}"}), 404

    try:
        # Prepare input features
        feature_data = {
            #"Name": patient.name,
            "Age": patient.age,
            "BMI": patient.bmi,
            "Respiratory_Rate": patient.respiratory_rate,
            "Diastolic_BP": patient.diastolic_bp,
            "Systolic_BP": patient.systolic_bp,
            "Temperature": patient.temperature,
            "SpO2": patient.spo2,
            "Heart_Rate": patient.heart_rate,
            "Glucose_Level": patient.glucose,
            "pH": patient.ph,
            "medical_history": patient.medical_history
        }

        # Convert to DataFrame with correct column names
        features_df = pd.DataFrame([feature_data])

        # Scale the features using the same scaler used during training
        features_scaled = scaler.transform(features_df)

        # Predict risk level
        risk_prediction = model.predict(features_scaled)[0]
        risk_levels = {0: "Stable", 1: "Moderate", 2: "Critical"}
        risk_level = risk_levels.get(risk_prediction, "Unknown")

        # Return patient info with predicted risk
        return jsonify({
            "patient_id": patient.id,
            "name": patient.name,
            "age": patient.age,
            "bmi": patient.bmi,
            "respiratory_rate": patient.respiratory_rate,
            "diastolic_bp": patient.diastolic_bp,
            "systolic_bp": patient.systolic_bp,
            "temperature": patient.temperature,
            "spo2": patient.spo2,
            "heart_rate": patient.heart_rate,
            "glucose": patient.glucose,
            "ph": patient.ph,
            "medical_history": patient.medical_history,
            "risk_level": risk_level
        })

    except Exception as e:
        print(f"Error predicting risk for patient {patient_id}: {str(e)}")
        return jsonify({"error": "An error occurred while processing data."}), 500

@api_routes.route("/icu_risk")
def icu_risk_page():
    return render_template("icu_risk.html")



# ✅ Edit Patient Details
@api_routes.route('/edit_patient/<int:id>', methods=['GET', 'POST'])
def edit_patient(id):
    patient = Patient.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            patient.name = request.form['name']
            patient.age = int(request.form['age'])
            patient.bmi = float(request.form['bmi'])
            patient.respiratory_rate = float(request.form['respiratory_rate'])  # ✅ Use float() instead of int()
            patient.diastolic_bp = float(request.form['diastolic_bp'])
            patient.systolic_bp = float(request.form['systolic_bp'])
            patient.temperature = float(request.form['temperature'])
            patient.spo2 = int(request.form['spo2'])
            patient.urine_output = request.form['urine_output']
            patient.glucose = float(request.form['glucose'])  # ✅ Ensure glucose is float
            patient.ph = float(request.form['ph'])
            patient.heart_rate = int(request.form['heart_rate'])
            patient.medical_history = request.form['medical_history']

            db.session.commit()
            flash("Patient updated successfully!", "success")
            return redirect(url_for('patients'))

        except ValueError as e:
            flash(f"Invalid input: {str(e)}", "danger")  # ✅ Handle invalid inputs properly
            return redirect(url_for('edit_patient', id=id))

    return render_template("edit_patient.html", patient=patient)


# ✅ DELETE: Remove a Patient Record
@api_routes.route('/delete_patient/<int:id>', methods=['POST'])
def delete_patient(id):
    patient = Patient.query.get_or_404(id)
    db.session.delete(patient)
    db.session.commit()
    flash("Patient deleted successfully!", "success")
    return redirect(url_for('patients'))

#analysis page

@api_routes.route('/api/analysis', methods=['GET'])
def analysis_api():
    try:
        # ✅ Check if model and scaler are loaded
        if model is None or scaler is None:
            return jsonify({"error": "Model or scaler not loaded"}), 500

        # ✅ Fetch all patient data
        patients = Patient.query.all()
        if not patients:
            return jsonify({"error": "No patient data found"}), 404

        # ✅ Initialize counters
        stable_count = 0
        moderate_count = 0
        critical_count = 0
        patient_details = []

        for patient in patients:
            try:
                # ✅ Prepare patient features for model input
                features_df = pd.DataFrame([[patient.age, patient.bmi, patient.respiratory_rate,
                                             patient.diastolic_bp, patient.systolic_bp, patient.temperature,
                                             patient.spo2, patient.heart_rate, patient.glucose, patient.ph,
                                             patient.medical_history]], columns=FEATURE_NAMES)

                # ✅ Scale the features
                features_scaled = scaler.transform(features_df)

                # ✅ Predict risk level
                risk_prediction = model.predict(features_scaled)[0]
                risk_levels = {0: "Stable", 1: "Moderate", 2: "Critical"}
                risk_level = risk_levels.get(risk_prediction, "Unknown")

                # ✅ Update patient risk level in database
                patient.risk_level = risk_level
                db.session.commit()

                # ✅ Categorize risk levels
                if risk_level == "Stable":
                    stable_count += 1
                elif risk_level == "Moderate":
                    moderate_count += 1
                elif risk_level == "Critical":
                    critical_count += 1

                # ✅ Store patient details
                patient_details.append({
                    "id": patient.id,
                    "name": patient.name,
                    "age": patient.age,
                    "risk_level": risk_level
                })

            except Exception as patient_error:
                print(f"Error processing patient {patient.id}: {str(patient_error)}")

        # ✅ Return aggregated data
        return jsonify({
            "total_patients": len(patients),
            "stable": stable_count,
            "moderate": moderate_count,
            "critical": critical_count,
            "patients": patient_details
        })

    except Exception as e:
        print(f"Error processing analysis: {str(e)}")
        return jsonify({"error": "Server error occurred"}), 500


@api_routes.route("/analysis")
def analysis():
    return render_template("analysis.html")

FEATURE_NAMES = ["Age", "BMI", "Respiratory_Rate", "Diastolic_BP", "Systolic_BP",
                 "Temperature", "SpO2", "Heart_Rate", "Glucose_Level", "pH", "medical_history"]


# ✅ Create Blueprint
live_risk_routes = Blueprint("live_risk_routes", __name__)

# ✅ Global Variable for Auto-Update Feature
AUTO_UPDATE = False

# ✅ Global Variable for Auto-Update

def generate_random_vitals(patient):
    """Generate realistic random vital signs for a patient."""
    patient.respiratory_rate = round(random.uniform(10, 25), 1)
    patient.diastolic_bp = round(random.uniform(50, 90), 1)
    patient.systolic_bp = round(random.uniform(80, 130), 1)
    patient.temperature = round(random.uniform(34.0, 40.0), 1)
    patient.spo2 = random.randint(85, 105)
    patient.heart_rate = random.randint(50, 120)
    patient.glucose = round(random.uniform(60, 130), 1)
    patient.ph = round(random.uniform(7.2, 7.5), 2)

def update_patient_data():
    """Continuously update patient vitals and predict their risk levels."""
    global AUTO_UPDATE
    while True:
        with app.app_context():  # ✅ Ensures database operations work inside Flask
            if AUTO_UPDATE:
                print("🔄 Auto-Updating Patient Data...")
                patients = Patient.query.all()
                for patient in patients:
                    generate_random_vitals(patient)
                      # ✅ Use model-based risk prediction
                db.session.commit()
        time.sleep(10)  # ✅ Update every 10 seconds

# ✅ Start Background Thread for Auto-Updates
threading.Thread(target=update_patient_data, daemon=True).start()


# ✅ API to Toggle Auto-Update
@live_risk_routes.route("/api/toggle_auto_update", methods=["POST"])
def toggle_auto_update():
    global AUTO_UPDATE
    AUTO_UPDATE = not AUTO_UPDATE
    return jsonify({"status": "ON" if AUTO_UPDATE else "OFF"})


# ✅ API to Get Auto-Update Status
@live_risk_routes.route("/api/get_auto_update_status", methods=["GET"])
def get_auto_update_status():
    return jsonify({"auto_update_status": "ON" if AUTO_UPDATE else "OFF"})


# ✅ Convert medical_history to a numerical value (if it was label encoded)
def encode_medical_history(medical_history):
    history_mapping = {"None": 0, "Mild": 1, "Chronic": 2, "Severe": 3}  # Adjust based on your training data
    return history_mapping.get(medical_history, 0)  # Default to 0 if unknown

# ✅ API for Live Risk Prediction (Single Patient)
@live_risk_routes.route("/api/live_risk/<int:patient_id>", methods=["GET"])
def live_risk_data(patient_id):
    patient = Patient.query.get(patient_id)
    if not patient:
        return jsonify({"error": "No patient data available"}), 404

    if model is None or scaler is None:
        return jsonify({"error": "Model or scaler not loaded"}), 500

    try:

        # ✅ Convert patient data to DataFrame with correct column names
        features_df = pd.DataFrame([[patient.age, patient.bmi, patient.respiratory_rate,
                                  patient.diastolic_bp, patient.systolic_bp, patient.temperature,
                                  patient.spo2, patient.heart_rate, patient.glucose, patient.ph, patient.medical_history]],
                                columns=FEATURE_NAMES)

        # ✅ Scale the features
        features_scaled = scaler.transform(features_df)

        # ✅ Predict risk level
        risk_prediction = model.predict(features_scaled)[0]
        risk_levels = {0: "Stable", 1: "Moderate", 2: "Critical"}
        risk_level = risk_levels.get(risk_prediction, "Unknown")

        # ✅ Update patient risk level in database
        patient.risk_level = risk_level
        db.session.commit()

        return jsonify({
            "patient_id": patient.id,
            "name": patient.name,
            "age": patient.age,
            "risk_level": risk_level
        })

    except Exception as e:
        print(f"Error predicting risk for patient {patient_id}: {str(e)}")
        return jsonify({"error": "An error occurred while processing data."}), 500


# ✅ API for Fetching All Patients' Live Risk Data
@live_risk_routes.route("/api/live_risk", methods=["GET"])
def live_risk():
    if model is None or scaler is None:
        return jsonify({"error": "Model or scaler not loaded"}), 500

    patients = Patient.query.all()
    if not patients:
        return jsonify({"error": "No patient data available"}), 404

    patient_data = []
    for patient in patients:
        try:
            # ✅ Convert patient data to DataFrame with correct column names
            features_df = pd.DataFrame([[patient.age, patient.bmi, patient.respiratory_rate,
                                  patient.diastolic_bp, patient.systolic_bp, patient.temperature,
                                  patient.spo2, patient.heart_rate, patient.glucose, patient.ph, patient.medical_history
                                    ]],
                                       columns=FEATURE_NAMES)

            # ✅ Scale the features
            features_scaled = scaler.transform(features_df)

            # ✅ Predict risk level
            risk_prediction = model.predict(features_scaled)[0]
            risk_levels = {0: "Stable", 1: "Moderate", 2: "Critical"}
            risk_level = risk_levels.get(risk_prediction, "Unknown")

            # ✅ Update patient risk level in database
            patient.risk_level = risk_level
            db.session.commit()

            patient_data.append({
                "id": patient.id,
                "name": patient.name,
                "age": patient.age,
                "risk_level": risk_level
            })

        except Exception as e:
            print(f"Error processing patient {patient.id}: {str(e)}")

    return jsonify({"patients": patient_data})


# ✅ Render Live Risk Monitoring Page
@live_risk_routes.route("/live_risk")
def live_risk_page():
    return render_template("live_risk.html")

