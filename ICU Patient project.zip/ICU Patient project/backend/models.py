from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///patients.db'

db = SQLAlchemy()
db.init_app(app)

class User(db.Model, UserMixin):
    __tablename__ = "users"  # Explicitly set table name
    __table_args__ = {'extend_existing': True}  # ✅ Allow redefinition

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)


# Patient Model
class Patient(db.Model):
    __tablename__ = "patients"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    bmi = db.Column(db.Float, nullable=False)
    respiratory_rate = db.Column(db.Float, nullable=False)
    diastolic_bp = db.Column(db.Float, nullable=False)
    systolic_bp = db.Column(db.Float, nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    spo2 = db.Column(db.Float, nullable=False)
    urine_output = db.Column(db.String(100), nullable=False)
    glucose = db.Column(db.Float, nullable=False)
    ph = db.Column(db.Float, nullable=False)
    heart_rate = db.Column(db.Integer, nullable=False)
    medical_history = db.Column(db.Text, nullable=True)
    record_date = db.Column(db.DateTime, default=datetime.utcnow)


with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)