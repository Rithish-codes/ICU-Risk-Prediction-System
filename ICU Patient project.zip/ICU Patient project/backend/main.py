import os
import sys
import traceback  # Add this at the top
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from sqlalchemy.orm import Session
from datetime import datetime
from flask_migrate import Migrate
from models import User, Patient, db 
from werkzeug.security import generate_password_hash
from app import app
from routes import api_routes ,live_risk_routes



# ✅ Register API routes AFTER app is created
app.register_blueprint(api_routes)
app.register_blueprint(live_risk_routes)


# Dashboard Route (Protected)
@app.route('/dashboard')
@login_required
def dashboard():
    try:
        # ✅ Fetch only necessary data to optimize query performance
        patients_count = db.session.query(Patient).count()
        critical_patients = Patient.query.filter_by(risk_level="Critical").count()
        moderate_patients = Patient.query.filter_by(risk_level="Moderate").count()
        stable_patients = Patient.query.filter_by(risk_level="Stable").count()

        return render_template("dashboard.html",
                               total_patients=patients_count,
                               critical_count=critical_patients,
                               moderate_count=moderate_patients,
                               stable_count=stable_patients)

    except Exception as e:
        print(f"Error in /dashboard route: {str(e)}")
        print(traceback.format_exc())  # Logs full stack trace
        return jsonify({"error": "An error occurred in the dashboard page"}), 500


#Api
@app.route("/api/patients", methods=["GET"])
def get_patients():
    try:
        patients = Patient.query.all()
        if not patients:
            return jsonify([])  # Return empty list instead of error

        patient_data = []
        for patient in patients:
            patient_data.append({
                "id": patient.id,
                "name": patient.name,
                "age": patient.age,
                "bmi": patient.bmi,
                "respiratory_rate": patient.respiratory_rate,
                "diastolic_bp": patient.diastolic_bp,
                "systolic_bp": patient.systolic_bp,
                "temperature": patient.temperature,
                "spo2": patient.spo2,
                "glucose": patient.glucose,
                "heart_rate": patient.heart_rate,
                "medical_history": patient.medical_history
            })

        return jsonify(patient_data)

    except Exception as e:
        print(f"Error fetching patients: {str(e)}")
        return jsonify({"error": "Server error occurred"}), 500




# Patients Table Route
@app.route('/patients')
@login_required
def patients():
    try:
        # Fetch all patients from the database
        patients_data = Patient.query.all()
        
        if not patients_data:
            flash("No patient records found!", "info")

        return render_template("patients.html", patients=patients_data)

    except Exception as e:
        print("Error fetching patient data:", str(e))
        print(traceback.format_exc())  # Debugging output
        flash("Error retrieving patient data!", "danger")
        return redirect(url_for('dashboard'))  # Redirect to the dashboard if an error occurs


# Add Patient Route
@app.route('/add_patient', methods=['GET', 'POST'])
@login_required
def add_patient():
    if request.method == "POST":
        name = request.form.get('name')
        age = int(request.form.get('age', 0))
        bmi = float(request.form.get('bmi', 0.0))
        respiratory_rate = int(request.form.get('respiratory_rate', 0))
        diastolic_bp = int(request.form.get('diastolic_bp', 0))
        systolic_bp = int(request.form.get('systolic_bp', 0))
        temperature = float(request.form.get('temperature', 0.0))
        spo2 = int(request.form.get('spo2', 0))
        urine_output = request.form.get('urine_output')
        glucose = request.form.get('glucose')
        ph = float(request.form.get('ph', 7.4))
        heart_rate = int(request.form.get('heart_rate', 0))
        medical_history = request.form.get('medical_history')
        record_date=datetime.utcnow()

        new_patient = Patient(
            name=name, age=age, bmi=bmi, respiratory_rate=respiratory_rate,
            diastolic_bp=diastolic_bp, systolic_bp=systolic_bp, temperature=temperature,
            spo2=spo2, urine_output=urine_output, glucose=glucose, ph=ph,
            heart_rate=heart_rate, medical_history=medical_history
        )

        db.session.add(new_patient)
        db.session.commit()
        flash("Patient added successfully!", "success")
        return redirect(url_for('patients'))

    # ✅ Always return a response, even for GET requests
    return render_template("add_patient.html")

# Fix Favicon 404 Error
@app.route('/favicon.ico')
def favicon():
    return '', 204  # Empty response with No Content stats



if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # ✅ Ensures database is initialized
    app.run(debug=True)